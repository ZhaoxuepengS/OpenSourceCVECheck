﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace UNPClient
{
    class Common
    {
       //SoftVPN命令缓存路径
        public static string TmpDirectory = Application.StartupPath+"\\Tmp";
        public static string getListBatPath = Application.StartupPath+"\\Tmp\\getVPNList.bat";
        public static string createVPNBatPath = Application.StartupPath + "\\Tmp\\createVPN.bat";
        public static string getListTmpPath = Application.StartupPath + "\\Tmp\\out.txt";
        public static string disconnectVPNBatPath = Application.StartupPath + "\\Tmp\\disconnect.bat";
        public static string getSingleConnPath = Application.StartupPath + "\\Tmp\\getSingleConn.bat";
        //用户连接信息默认存储路径
        public static string userInfoPath = Application.StartupPath + "\\Tmp\\usr.bin";
        //路由文件文件路径
        public static string RouteUrl = ":8089\\";
        public static string RoutenFilePath = Application.StartupPath + "\\Tmp\\route.xml";
    }
}
