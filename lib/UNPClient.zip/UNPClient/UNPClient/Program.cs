﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UNPClient
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            VpnConnection vpnconn = new VpnConnection("VSTest", "10.222.197.18", "443", "default", "admin", "123456");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1(vpnconn));

            //string s = "vpncmd /CLIENT localhost /CMD accountList >d:/out.txt";
          
            //SoftVPN testrun = new SoftVPN();
            //testrun.getVpnList();
            //bool tmp = testrun.ifVpnConnExist("Test");
            //MessageBox.Show(tmp.ToString());
           
            //testrun.CreateVpnConn(vpnconn);
            //Thread.Sleep(5000);
            //testrun.updateVpnConn(vpnconn);
            //testrun.ConnectVpnServer(vpnconn);
            //int i = 0;
            //while(i<50){
            //    Console.WriteLine(testrun.getVpnConnStatus(vpnconn.VpnConName));
            //    Thread.Sleep(1000);
            //    i++;
            //}          
        }
    }
}
