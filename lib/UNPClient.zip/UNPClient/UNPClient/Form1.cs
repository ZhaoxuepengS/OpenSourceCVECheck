﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UNPClient
{
    public partial class Form1 : Form
    {
        private delegate void FlushClient(StringBuilder sb);//代理
        VpnConnection vpnconn = null;
        SoftVPN vpn = new SoftVPN();
        MainForm MainForm = null;
        public Form1(VpnConnection vpnconn,MainForm MainForm)
        {
            InitializeComponent();
            this.vpnconn = vpnconn;
            this.MainForm = MainForm;
        }

        private void loadingForm_Load(object sender, EventArgs e)
        {
            //Thread thread = new Thread(CrossThreadFlush);
            //thread.IsBackground = true;
            //thread.Start();
            //this.Focus();
            this.Activate();
            
        }
        //private void CrossThreadFlush() {
        //    StringBuilder sb = new StringBuilder("正在连接VPN服务器。。。");
        //    SoftVPN vpn = new SoftVPN();
        //    while (true) { 
        //        //将Sleep和无限循环放在等待异步的外面
        //        Thread.Sleep(1000);
        //        string statusStr = vpn.getVpnConnStatus(vpnconn.VpnConName);
        //        ThreadFunction(sb);
        //        if ("连接失败，请检查目标地址是否正确。".Equals(statusStr) || "连接成功".Equals(statusStr))
        //        {
        //            status = statusStr;
        //            break;

        //        }
        //        //if (sb.Length == 10) {
        //        //    sb.Remove(4, 6);
        //        //}
        //        //sb.Append("·");

        //    } 
        //}
        //private void ThreadFunction(StringBuilder sb) {
        //    if (this.label1.InvokeRequired)//等待异步
        //    {
        //        FlushClient fc = new FlushClient(ThreadFunction);
        //        this.Invoke(fc,new object[]{sb});//通过代理调用刷新方法
        //    }
        //    else
        //    {
        //        this.label1.Text = sb.ToString();
        //    }
        //}

        private void timer1_Tick(object sender, EventArgs e)
        {

           
            
            string statusStr = vpn.getVpnConnStatus(vpnconn.VpnConName);
            this.label1.Text = statusStr;
            if ("连接完成 (会话建立)".Equals(statusStr))
            {
                MainForm.IsConnSuccess = true;
                timer1.Stop();
                Thread.Sleep(2000);
                MainForm.setButton1UnVisble();
                MainForm.setButton3Visable();
                this.Close();
                               
            }
            else if ("连接失败，请检查目标地址是否正确。".Equals(statusStr)) {
                MainForm.IsConnSuccess = false;
                timer1.Stop();                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vpn.DisconnectVpnServer(vpnconn);
            closing();
        }
        private void closing() {
            this.Dispose();
            //this.Close();
            MainForm.Show();
            MainForm.WindowState = FormWindowState.Normal;
            MainForm.Activate();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            closing();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

     
       
    }
}
