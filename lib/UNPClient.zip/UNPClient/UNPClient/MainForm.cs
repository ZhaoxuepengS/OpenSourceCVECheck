﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Xml;  


namespace UNPClient
{
    public partial class MainForm : Form
    {
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string userInfoPath = "D:\\SoftVPNTmp\\usr.bin";
        SoftVPN softVpn = new SoftVPN();
        VpnConnection vpnConn = null;
        public bool IsConnSuccess = false;
        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;
            getRemeberInfo();
 

        }

        //点击连接按钮
        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;

            vpnConn = new VpnConnection("UNP_Connection", IpAddrText.Text, PortComboBox.Text, "default", UsernameText.Text, PasswordText.Text);
            
            /*
             自动登录
            */
            if (checkBox_autoLogin.Checked)
            {
                SaveConfig("1", "autoLogin");
            }
            else {
                SaveConfig("0", "autoLogin");
            }

            softVpn.createVpnConnectStatusBat(vpnConn.VpnConName);


            
            log.Info("填写完毕，开始连接VPN Server");
           
            //判断连接是否已经存在
            //bool VpnExist = softVpn.ifVpnConnExist(vpnConn.VpnConName);
            //if (VpnExist)
            //{
                //连接已经存在，重新配置连接
            //    log.Info("连接已经存在，重新配置连接");
            softVpn.updateVpnConn(vpnConn);
            this.Hide();
            //}
            //else
            //{
            //    log.Info("连接不存在，创建新的连接");
            //    softVpn.CreateVpnConn(vpnConn);
            //}
            log.Info("连接VPN服务器。。。");
            softVpn.ConnectVpnServer(vpnConn);  

            Form1 form = new Form1(vpnConn, this);
            form.ShowDialog();

            if (IsConnSuccess)
            {
                this.WindowState = FormWindowState.Minimized;    //使关闭时窗口向右下角缩小的效果
                //隐藏任务栏区图标
                this.ShowInTaskbar = false;
                this.notifyIcon1.Visible = true;
                //气球提示           
                this.notifyIcon1.ShowBalloonTip(3, "提示", "UNP已成功连接！\n如要打开，请点击图标", ToolTipIcon.Info);  
                /*
                * 记住密码
                */
                remeberPasswd(vpnConn);
            }
            else {
                button1.Enabled = true;
                this.Activate();           
            }

           
                 
        }

        //点击退出按钮
        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();         
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            checkAllTextBoxEmpty();
        }
 
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            checkAllTextBoxEmpty();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            checkAllTextBoxEmpty();
        }

        private bool checkAllTextBoxEmpty()
        {
            if (IpAddrText.Text.Trim() == "" || UsernameText.Text.Trim() == "" || PasswordText.Text.Trim() == "")
            {
                return true;
            }
            button1.Enabled = true;
            return false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox_remeberPasswd.Checked)
            {
                checkBox_autoLogin.Enabled = true;
            }
            else {
                checkBox_autoLogin.Checked = false;
                checkBox_autoLogin.Enabled = false;
            }
        }
        //记住密码处理事件
        private void remeberPasswd(VpnConnection vpnConn) {
            if (checkBox_remeberPasswd.Checked)
            {
                vpnConn.VpnPassword = Encryption(vpnConn.VpnPassword);
                FileStream fs = new FileStream(userInfoPath, FileMode.OpenOrCreate);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, vpnConn);      
                fs.Close();
                vpnConn.VpnPassword = PasswordText.Text;
                SaveConfig("1","remeberPasswd");
                

            }
            else {
                vpnConn.VpnPassword = "";
                FileStream fs = new FileStream(userInfoPath, FileMode.OpenOrCreate);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, vpnConn);
                fs.Close();
                vpnConn.VpnPassword = PasswordText.Text;
                SaveConfig("0", "remeberPasswd");
            }
        }
        //自动登录处理事件
        private void autoLogin() {
            if (checkBox_autoLogin.Checked)
            {
                button1_Click(null,new EventArgs());
            }
        }
        //获取保存的账户信息
        private void getRemeberInfo() {
            if (File.Exists(userInfoPath))
            {
                FileStream fs = new FileStream(userInfoPath, FileMode.OpenOrCreate);
                if (fs.Length > 0)
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    //读出存在Data.bin 里的用户信息
                    VpnConnection vpnConn = bf.Deserialize(fs) as VpnConnection;
                    UsernameText.Text = vpnConn.VpnUsername;
                    if (!("".Equals(vpnConn.VpnPassword))) {
                        vpnConn.VpnPassword = Decrypt(vpnConn.VpnPassword);
                        PasswordText.Text = vpnConn.VpnPassword;
                    }     
                    IpAddrText.Text = vpnConn.VpnConAddr;
                    PortComboBox.Text = vpnConn.VpnConPort;
                }
                fs.Close();
            }
            if ("0".Equals(ConfigurationManager.AppSettings["remeberPasswd"]))
            {
                checkBox_remeberPasswd.Checked = false;
            }
            else if("1".Equals(ConfigurationManager.AppSettings["remeberPasswd"])){
                checkBox_remeberPasswd.Checked = true;
            }
            if ("0".Equals(ConfigurationManager.AppSettings["autoLogin"]))
            {              
                checkBox_autoLogin.Checked = false;
            }
            else if ("1".Equals(ConfigurationManager.AppSettings["autoLogin"]))
            {
                checkBox_autoLogin.Checked = true;
            }
        }
        //保存配置文件
        private void SaveConfig(string ConnenctionString, string strKey)
        {
            XmlDocument doc = new XmlDocument();
            //获得配置文件的全路径    
            string strFileName = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
            // string  strFileName= AppDomain.CurrentDomain.BaseDirectory + "\\exe.config";    
            doc.Load(strFileName);
            //找出名称为“add”的所有元素    
            XmlNodeList nodes = doc.GetElementsByTagName("add");
            for (int i = 0; i < nodes.Count; i++)
            {
                //获得将当前元素的key属性    
                XmlAttribute att = nodes[i].Attributes["key"];
                //根据元素的第一个属性来判断当前的元素是不是目标元素    
                if (att.Value == strKey)
                {
                    //对目标元素中的第二个属性赋值    
                    att = nodes[i].Attributes["value"];
                    att.Value = ConnenctionString;
                    break;
                }
            }
            //保存上面的修改    
            doc.Save(strFileName);
            System.Configuration.ConfigurationManager.RefreshSection("appSettings");
        }    
        //加密
        private string Encryption(string express)
        {
            CspParameters param = new CspParameters();
            param.KeyContainerName = "oa_erp_dowork_zxpTestzzzzzzzzzzzzzzzzz";//密匙容器的名称，保持加密解密一致才能解密成功
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(param))
            {
                byte[] plaindata = Encoding.Default.GetBytes(express);//将要加密的字符串转换为字节数组
                byte[] encryptdata = rsa.Encrypt(plaindata, false);//将加密后的字节数据转换为新的加密字节数组
                return Convert.ToBase64String(encryptdata);//将加密后的字节数组转换为字符串
            }
        }

        //解密
        private string Decrypt(string ciphertext)
        {
            CspParameters param = new CspParameters();
            param.KeyContainerName = "oa_erp_dowork_zxpTestzzzzzzzzzzzzzzzzz";
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(param))
            {
                byte[] encryptdata = Convert.FromBase64String(ciphertext);
                try
                {
                    byte[] decryptdata = rsa.Decrypt(encryptdata, false);
                    return Encoding.Default.GetString(decryptdata);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.StackTrace);
                }
                return "";
                
            }
        }

        //双击托盘图标显示窗体
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                notifyIcon1.Visible = false;
            }
        }

        public void setButton1UnVisble()
        {
            this.button1.Visible = false;
        }

        public void setButton3Visable() {
            this.button3.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            softVpn.DisconnectVpnServer(vpnConn);
            button3.Enabled = false;
            button1.Enabled = true;
            button1.Visible = true;
            button3.Visible = false;
        }


        private void 显示ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                notifyIcon1.Visible = false;
            }
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {       
                this.Close();            
        }

        private void 断开连接ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            softVpn.DisconnectVpnServer(vpnConn);
            button3.Enabled = false;
            button1.Enabled = true;
            button1.Visible = true;
            button3.Visible = false;
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            //判断是否选择的是最小化按钮
            if (WindowState == FormWindowState.Minimized)
            {
                //隐藏任务栏区图标
                this.ShowInTaskbar = false;
                //图标显示在托盘区
                notifyIcon1.Visible = true;
                //气球提示           
                this.notifyIcon1.ShowBalloonTip(3, "提示", "UNP已最小化运行！\n如要打开，请点击图标", ToolTipIcon.Info);  
            }
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            autoLogin();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            DialogResult dr = MessageBox.Show("退出客户端将会断开UNP连接，确定要退出吗?", "退出系统", messButton);
            if (dr == DialogResult.OK)
            {
                if (vpnConn != null)
                {
                    softVpn.DisconnectVpnServer(vpnConn);
                }
                e.Cancel = false;
            }
            else {
                e.Cancel = true; 
                
            }
        }
    }
}
