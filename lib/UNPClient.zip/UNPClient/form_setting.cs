﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Configuration;

namespace UNPClient
{
    public partial class form_setting :Form
    {
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);  
        private MainForm MainForm = null;
        public form_setting(MainForm mainform)
        {
            InitializeComponent();
            this.MainForm = mainform;
        }

        private void form_setting_Load(object sender, EventArgs e)
        {
            // 
            // ipBox
            // 
            this.groupBox1.Controls.Add(IpBox1);
            this.IpBox1.Location = new System.Drawing.Point(78, 48);
            this.IpBox1.Name = "ipBox";
            // 
            // ipBox2
            //       
            this.groupBox2.Controls.Add(IpBox2);
            this.IpBox2.Location = new System.Drawing.Point(79, 54);
            this.IpBox2.Name = "ipBox2";
            //radio按钮效果
            if (radioButton1.Checked) {
                this.IpBox1.setEnabled(false);
            }
            else if (radioButton2.Checked) {
                this.IpBox1.setEnabled(true);
            }

            if (radioButton4.Checked)
            {
                this.IpBox2.setEnabled(false);
            }
            else if (radioButton3.Checked)
            {
                this.IpBox2.setEnabled(true);
            }
            //加载配置
            if(!("".Equals(ConfigurationManager.AppSettings["ClientIP"]))){
                IpBox1.IpAddressString = ConfigurationManager.AppSettings["ClientIP"];
            }
            if (!("".Equals(ConfigurationManager.AppSettings["vmIpAddr"])))
            {
                IpBox2.IpAddressString = ConfigurationManager.AppSettings["vmIpAddr"];
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                this.IpBox1.setEnabled(true);
            }
            else {
                this.IpBox1.setEnabled(false);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                this.IpBox2.setEnabled(true);
            }
            else
            {
                this.IpBox2.setEnabled(false);
            }
        }
        
        private IpInputBox IpBox1 = new IpInputBox(false);
        private IpInputBox IpBox2 = new IpInputBox(false);

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                string VMIp = IpBox2.IpAddressString;
                MainForm.SaveConfig(VMIp, "vmIpAddr");
            }
            else {
                MainForm.SaveConfig("","vmIpAddr");
            }

            if (radioButton2.Checked)
            {
                string clientIP = IpBox1.IpAddressString;
                string cmd = "netsh interface ip set address name=\"VPN\" static " + clientIP + " 255.255.255.0";
                MainForm.SaveConfig(clientIP, "ClientIP");
                execCmd(cmd);
            }
            else {
                string cmd = "netsh interface ip set address name=\"VPN\" source=dhcp";
                execCmd(cmd);
            }
            this.Close();
        }

        private bool execCmd(string cmd) {
            try
            {
                Process p = new Process();
                p.StartInfo.FileName = "cmd.exe";
                //是否使用操作系统shell启动
                p.StartInfo.UseShellExecute = false;
                // 接受来自调用程序的输入信息
                p.StartInfo.RedirectStandardInput = true;
                //输出信息
                p.StartInfo.RedirectStandardOutput = true;
                // 输出错误
                p.StartInfo.RedirectStandardError = true;
                //不显示程序窗口
                p.StartInfo.CreateNoWindow = true;
                //启动程序
                p.Start();

                p.StandardInput.WriteLine(cmd + "&exit");
                p.WaitForExit();
                p.Close();
            }
            catch (Exception e) {
                log.Info("执行设置IP命令出错"+e.StackTrace);
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
