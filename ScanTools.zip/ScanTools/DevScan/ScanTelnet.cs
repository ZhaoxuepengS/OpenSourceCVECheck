﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace DevScan
{
    class ScanTelnet
    {
        private string telip;
        private string teluser;
        private string telpasswd;

        PIEBALD.Types.TelnetSocket tel;
        public ScanTelnet(string ip,string use,string pass)
        {
            telip = ip;
            teluser = use;
            telpasswd = pass;
        }
        ~ScanTelnet()
        {

        }
        public void Close()
        {

        }

        private string RecvBuf;
        private AutoResetEvent autoEvent = new AutoResetEvent(false);
        public bool Connect()
        {

            bool rLogInFailed = true;
            tel = new PIEBALD.Types.TelnetSocket();
            tel.OnDataReceived += tel_OnDataReceived;
            try
            {
                /*
                 1、NVR和DVR，telnet后首先进入login界面，等待ogin：出现，输入username后等待assword出现，登录后若出现BusyBox则表明登录成功；
                 2、IPC，telnet后首先进入login界面，等待ogin：出现，，输入username后等待assword出现，登录后若出现root则表明登录成功；
                 3、EC和DC，telnet后首先进入login界面，等待ogin：出现，，输入username后等待assword出现，登录后若出现~#则表明登录成功；
                 3、交换机，telnet后直接输入密码登录，等待assword：出现，登录后若不出现%则表明登录成功。
                 */

                tel.Connect(telip);
                System.Diagnostics.Debug.Print(telip + " telnet connect...");
                bool evrt = autoEvent.WaitOne(5000);
                string xxx = RecvBuf;
                for (int i = 100; i < 1500; i += 100)
                {
                    xxx = RecvBuf;
                    if (xxx == null)
                    {
                        tel.Close();
                        System.Diagnostics.Debug.Print(telip + " Close");
                        tel.Dispose();
                        return true;
                    }
                    if (xxx.Contains("ogin:"))
                    {
                        //login
                        tel.WriteLine(teluser);
                        System.Diagnostics.Debug.Print(telip + " telnet: " + teluser);
                        autoEvent.WaitOne();
                        for (int j = 100; j < 1000; j += 100)
                        {
                            xxx = RecvBuf;
                            if (xxx.Contains("assword:"))
                            {
                                tel.WriteLine(telpasswd);
                                System.Diagnostics.Debug.Print(telip + " telnet: " + telpasswd);
                                autoEvent.WaitOne();
                                for (int k = 100; k < 1000; k += 100)
                                {
                                    xxx = RecvBuf;
                                    if (xxx.Contains("BusyBox") || xxx.Contains("uniview@") || xxx.Contains("~ #") || xxx.Contains("#") || xxx.Contains("/root>"))
                                    {
                                        tel.Close();
                                        System.Diagnostics.Debug.Print(telip + " 嵌入式(" + RecvBuf+")");
                                        rLogInFailed = false;
                                        
                                        break;
                                    }
                                    {
                                        Thread.Sleep(100);
                                    }
                                }
                                
                                break;
                            }
                            else
                            { 
                                Thread.Sleep(100); 
                            }
                        }
                        
                        break;
                    }

                    else if (xxx.Contains("assword:"))
                    {
                        // Thread.Sleep(200);
                        System.Diagnostics.Debug.Print(telip + " ------------- ");
                        // 交换机直接输入Password
                        tel.WriteLine(telpasswd);
                        System.Diagnostics.Debug.Print(telip + " telnet: " + telpasswd);
                        autoEvent.WaitOne();
                        for (int j = 100; j < 10000; j += 100)
                        {
                            xxx = RecvBuf;
                            if (xxx.Contains("%Wrong") || xxx.Contains("%Username or password is invalid."))
                            {
                                // 显示 %Wrong                                
                                rLogInFailed = true;
                                break;
                            }
                            else 
                            {
                                // tel.Close();
                                // System.Diagnostics.Debug.Print(telip + " 交换机？？");
                                rLogInFailed = false;
                                Thread.Sleep(100);
                            }
                        }
                        
                        break;
                    }
                    else
                    { 
                        Thread.Sleep(100); 
                    }
                }
                tel.Close();
                System.Diagnostics.Debug.Print(telip + " Close");
                tel.Dispose();
                return rLogInFailed;
            } 
            catch (System.Net.Sockets.SocketException ex)
            {
                throw (ex);
            }
        }

        private void tel_OnDataReceived(string Data)
        {
            RecvBuf = Data;
            autoEvent.Set();
            System.Diagnostics.Debug.Print(telip + " telnet recvied:"+Data);
        }
        
    }
}
