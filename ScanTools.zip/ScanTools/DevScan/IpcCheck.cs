﻿
using System;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;

public class IpcCheck
{
    public const Int32 SCAN_UNKNOWN = -100;     // 代码未考虑到的错误
    public const Int32 SCAN_SOCKET_TIME_OUT = -4;
    public const Int32 SCAN_SOCKET_REJECT = -3;
    public const Int32 SCAN_PROTOCOL_TIME_OUT = -2;
    public const Int32 SCAN_PROTOCOL_REJECT = -1;
    public const Int32 SCAN_LOGIN_OK = 0;
    public const Int32 SCAN_LOGIN_FAILED = 1;
    public const Int32 SCAN_LOGIN_USERNOTEXIT = 2;

    [DllImport("PasswdTransfer.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern long PasswdTransferFunc(string strPasswd, int ulInputLen, int ulOutSize, System.Text.StringBuilder strNewPasswd);
    static string GetItemData(string strInput)
    {
        int i = 0;
        string strOutput = "";
        for (i = 0; i < strInput.Length; i++)
        {
            String strTmp = System.String.Format("<item>{0:D}</item>", (int)strInput[i]);
            strOutput = strOutput + strTmp;
        }
        for (i = 0; i < 64 - strInput.Length; i++)
        {
            String strTmp = System.String.Format("<item>0</item>");
            strOutput = strOutput + strTmp;
        }
        return strOutput;
    }
    public static int CheckIPCPasswd(string strIpAddr, string strUsrName, string strPasswd)
    {
        String strRequestUrl = System.String.Format("http://{0:G}:81/", strIpAddr);

        System.Text.StringBuilder strNewPasswd = new StringBuilder(256);
        IpcCheck.PasswdTransferFunc(strPasswd, strPasswd.Length, strPasswd.Length * 2 + 1, strNewPasswd);

        HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(strRequestUrl));
        myReq.Timeout = 5000;
        myReq.ReadWriteTimeout = 10000;
        myReq.Method = "POST";
        myReq.ContentType = "application/x-www-form-urlencoded";
        string strUsrNameData = GetItemData(strUsrName);
        string strIpAddrData = GetItemData(strIpAddr);
        string strPasswdData = GetItemData(strNewPasswd.ToString());

        string postData1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xop=\"http://www.w3.org/2004/08/xop/include\" xmlns:xmime4=\"http://www.w3.org/2004/11/xmlmime\" xmlns:wsa5=\"http://www.w3.org/2005/08/addressing\" xmlns:wsrf-bf=\"http://docs.oasis-open.org/wsrf/bf-2\" xmlns:wstop=\"http://docs.oasis-open.org/wsn/t-1\" xmlns:wsrf-r=\"http://docs.oasis-open.org/wsrf/r-2\" xmlns:tes-e=\"http://www.onvif.org/ver10/events/wsdl/EventBinding\" xmlns:tev=\"http://www.onvif.org/ver10/events/wsdl\" xmlns:tes-nc=\"http://www.onvif.org/ver10/events/wsdl/NotificationConsumerBinding\" xmlns:tes-np=\"http://www.onvif.org/ver10/events/wsdl/NotificationProducerBinding\" xmlns:tes-sm=\"http://www.onvif.org/ver10/events/wsdl/SubscriptionManagerBinding\" xmlns:xmime=\"http://www.w3.org/2004/06/xmlmime\" xmlns:tt=\"http://www.onvif.org/ver10/schema\" xmlns:wsnt=\"http://docs.oasis-open.org/wsn/b-2\" xmlns:tds=\"http://www.onvif.org/ver10/device/wsdl\" xmlns:timg=\"http://www.onvif.org/ver20/imaging/wsdl\" xmlns:tmd=\"http://www.onvif.org/ver10/deviceIO/wsdl\" xmlns:tptz=\"http://www.onvif.org/ver20/ptz/wsdl\" xmlns:trt=\"http://www.onvif.org/ver10/media/wsdl\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" xmlns:ter=\"http://www.onvif.org/ver10/error\" xmlns:tns1=\"http://www.onvif.org/ver10/topics\" xmlns:tan=\"http://www.onvif.org/ver20/analytics/wsdl\" xmlns:tan-ae=\"http://www.onvif.org/ver20/analytics/wsdl/AnalyticsEngineBinding\" xmlns:tan-re=\"http://www.onvif.org/ver20/analytics/wsdl/RuleEngineBinding\"><SOAP-ENV:Body><SDK-Login><pstUserLoginInfo>";
        string postData2 = "<szUserName xsi:type=\"SOAP-ENC:Array\" SOAP-ENC:arrayType=\"CHAR[64]\">" + strUsrNameData + "</szUserName>";
        string postData3 = "<szPassword xsi:type=\"SOAP-ENC:Array\" SOAP-ENC:arrayType=\"CHAR[64]\">" + strPasswdData + "</szPassword>";
        string postData4 = "<szUserID xsi:type=\"SOAP-ENC:Array\" SOAP-ENC:arrayType=\"CHAR[48]\"><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item><item>0</item></szUserID>";
        string postData5 = "<szServerIP xsi:type=\"SOAP-ENC:Array\" SOAP-ENC:arrayType=\"CHAR[64]\">" + strIpAddrData + "</szServerIP>";
        string postData6 = "<usServerPort>81</usServerPort></pstUserLoginInfo></SDK-Login></SOAP-ENV:Body></SOAP-ENV:Envelope>";
        string postData = postData1 + postData2 + postData3 + postData4 + postData5 + postData6;

        UTF8Encoding encoding = new UTF8Encoding();
        byte[] byte1 = encoding.GetBytes(postData);
        myReq.ContentLength = byte1.Length;
        try
        {
            Stream newStream = myReq.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            newStream.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine("连接失败");
            return SCAN_SOCKET_TIME_OUT;
        }

        try
        {
            HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
            Stream receiveStream = response.GetResponseStream();
            StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
            String receive = readStream.ReadToEnd();
            if (response.StatusDescription == "OK")
            {
                Console.WriteLine("登录成功");
                response.Close();
                readStream.Close();
                return SCAN_LOGIN_OK;
            }
            else
            {
                Console.WriteLine("登录失败");
                response.Close();
                readStream.Close();
                return SCAN_SOCKET_REJECT;
            }
        }
        catch (WebException e)
        {
            Console.WriteLine(e.Message);
            string Charset="";
            HttpWebResponse response = e.Response as HttpWebResponse;
            if (response == null)
            {
                return SCAN_SOCKET_REJECT;
            }
            if (response.StatusCode == HttpStatusCode.InternalServerError)
            {
                Stream s = response.GetResponseStream();
                StreamReader objReader = new StreamReader(s, Encoding.UTF8);
                string strline = "";
                //读取
                while (strline != null)
                {
                    strline = objReader.ReadLine();
                    if (strline != null)
                    {
                        Charset += strline.Trim();
                    }
                }
                if (Charset.Contains("sdk user invalid"))
                {
                    return SCAN_LOGIN_USERNOTEXIT;
                }
                else if (Charset.Contains("user password invalid"))
                {
                    return SCAN_LOGIN_FAILED;
                }
                else 
                {
                    return SCAN_SOCKET_REJECT;
                }
            }
            else
            {
                return SCAN_PROTOCOL_REJECT;
            }           
        }
    }
}