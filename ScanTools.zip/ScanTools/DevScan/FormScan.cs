﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Net.NetworkInformation;
using System.IO;
using Renci.SshNet;
using System.Diagnostics;
using Microsoft.Win32;//注册表操作要引用的空间
using System.Runtime.InteropServices;//调用API函数需要的引用，来加载非托管类user32.dll
using System.Security.Cryptography;
using System.Xml;
using System.Configuration;

namespace DevScan
{    
    public partial class FormScan : Form
    {
        public const Int32 SCAN_UNKNOWN = -100;     // 代码未考虑到的错误
        public const Int32 SCAN_SOCKET_TIME_OUT = -4;
        public const Int32 SCAN_SOCKET_REJECT = -3;
        public const Int32 SCAN_PROTOCOL_TIME_OUT = -2;
        public const Int32 SCAN_PROTOCOL_REJECT = -1;
        public const Int32 SCAN_LOGIN_OK = 0;
        public const Int32 SCAN_LOGIN_FAILED = 1;
        public const Int32 SCAN_LOGIN_USERNOTEXIT = 2;
        public const Int32 SCAN_NOJAVA = 3;

        private List<string> UserNameList = new List<string>();
        private List<string> PasswordList = new List<string>();
        
        private delegate Int32 TryLogInInvokeCallback(string IPAddr,string UserName,string Password);
        class TestMethod
        {
            public TryLogInInvokeCallback func;
            public string Desc;
            public bool IsVM = false;       // 侦测到是VM系列产品   
            public bool IsDevice = false;   // 侦测到是我司的设备
            
            //public bool IsIP = false;       // 侦测到有反应
        }

        private List<TestMethod> FunctionList = new List<TestMethod>();

        private Int32 TryLoginViaTelnet(string IPAddr,string UserName,string Password)
        {
            Ping pingSender = new Ping();
            PingReply reply = pingSender.Send(IPAddr);
            if (reply.Status == IPStatus.Success)
            {
                Int32 retval = 0;

                ScanTelnet tel = new ScanTelnet(IPAddr, UserName, Password);

                try
                {
                    bool r = tel.Connect();
                    if (r == true)
                    {
                        retval = SCAN_LOGIN_FAILED;
                    }
                    else if (r == false)
                    {
                        retval = SCAN_LOGIN_OK;
                    }
                }
                catch (System.Net.Sockets.SocketException ex)
                {
                    switch (ex.ErrorCode)
                    {
                        case 10060:
                            retval = SCAN_SOCKET_TIME_OUT;
                            break;

                        case 10061:
                            retval = SCAN_SOCKET_REJECT;
                            break;

                        default:
                            retval = SCAN_UNKNOWN;
                            break;
                    }
                }
                catch (Exception ex)
                {
                    retval = SCAN_UNKNOWN;
                }
                tel.Close();
                return retval;
            }
            else
            {
                return SCAN_SOCKET_TIME_OUT;
            }
        }
        private Int32 TryLoginViaSSH(string IPAddr, string UserName, string Password)
        {
            System.Diagnostics.Debug.Print(DateTime.Now.ToString()+"  Begin SSH login：" + IPAddr );
            SshClient sshclient = new SshClient(IPAddr, UserName, Password);
            var x = sshclient.ConnectionInfo.Timeout = new TimeSpan(0,0,5);

            Int32 retval = 0;
            try
            {
                sshclient.Connect();
                // PrintLines("OK");
                sshclient.Disconnect();
                // return true;
            }
            catch (Renci.SshNet.Common.SshOperationTimeoutException ex)
            {
                retval = SCAN_PROTOCOL_TIME_OUT;
            }
            catch(Renci.SshNet.Common.SshConnectionException ex)
            {
                retval = SCAN_SOCKET_TIME_OUT;
            }
            catch(System.Net.Sockets.SocketException ex)
            {
                switch(ex.ErrorCode)
                {
                    case 10060:
                        retval = SCAN_SOCKET_TIME_OUT;
                        break;

                    case 10061:
                        retval = SCAN_SOCKET_REJECT;
                        break;

                    default:
                        retval = SCAN_UNKNOWN;
                        break;
                }                
            }
            catch (System.Exception ex)
            {
                sshclient = null;
                retval = SCAN_LOGIN_FAILED;
            }
            System.Diagnostics.Debug.Print(DateTime.Now.ToString() + " SSH Return: " + IPAddr);
            return retval;
        }
        private Int32 TryLoginAsECDC(string IPAddr, string UserName, string Password)
        {
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string b = BitConverter.ToString(output).Replace("-", "");
            b = b.ToLower();

            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create("http://" + IPAddr + "/cgi-bin/main.cgi"));
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";
            myReq.Timeout = 5000;
            myReq.ReadWriteTimeout = 10000;
            string postData = "username=" + UserName + "&passwd=" + b+"&web_id=1&langinfo=0";
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] byte1 = encoding.GetBytes(postData);

            myReq.ContentLength = byte1.Length;

            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
        
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                if (receive.Contains("passport"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else
                {
                    Console.WriteLine("登录失败");
                }
                return SCAN_LOGIN_FAILED;
            }
            catch (Exception exp)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            } 
        }
        private Int32 TryLoginAsVM(string IPAddr, string UserName, string Password)
        {         
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string md5passwd = BitConverter.ToString(output).Replace("-", "");
            md5passwd = md5passwd.ToLower();
            
            string deviceurl = "http://" + IPAddr + "/Page/Main/index.php";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";

            //收集所有网卡的MAC地址
            string macAddress = "";
            string macAddressList = "";
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface adapter in nics)
            {
                if (!adapter.GetPhysicalAddress().ToString().Equals(""))
                {
                    macAddress = adapter.GetPhysicalAddress().ToString();
                    for (int i = 1; i < 6; i++)
                    {
                        macAddress = macAddress.Insert(3 * i - 1, "-");
                    }
                    macAddressList = macAddressList + macAddress+"%7c";
                }
            }
            macAddressList = macAddressList.ToLower();
            string postData = "username=" + UserName + "&passwd=" + Password + "&password=" + md5passwd +"&txtMacList="+ macAddressList + "*202.169.81.110";
            //string postData = "username=admin&passwd=test123&password=cc03e747a6afbbcbf8be7668acfebee5&txtMacList=00-0a-f7-0e-8b-a2%7C90-b1-1c-a5-9a-91%7C*202.169.81.118";
            ASCIIEncoding encoding = new ASCIIEncoding();

            // Set the content type of the data being posted;
            byte[] byte1 = encoding.GetBytes(postData);
            // Set the content length of the string being posted.
            myReq.ContentLength = byte1.Length;
            //myReq.Referer="http://202.169.31.110/Page/Login/index.php";
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //根据返回关键字段判断登陆结果
                if (receive.Contains("var errMsg = {"))
                {
                    Console.WriteLine("登录失败");
                    if (receive.Contains("code:\"1371\""))
                    {
                        Console.WriteLine("登录密码错误");
                        return SCAN_LOGIN_FAILED;
                    }
                    else if (receive.Contains("code:\"12351\""))
                    {
                        Console.WriteLine("用户名不存在");
                        return SCAN_LOGIN_USERNOTEXIT;
                    }
                    else if (receive.Contains("code:\"4035\""))
                    {
                        Console.WriteLine("该用户已登录");
                        return SCAN_LOGIN_USERNOTEXIT; // 退出该用户，当做登录失败？
                    }
                    else if (receive.Contains("code:\"1378\""))
                    {
                        Console.WriteLine("登陆PC的IP地址不符合此用户的IP地址限制策略");
                        return SCAN_LOGIN_OK; //???
                    }
                    else if (receive.Contains("code:\"1379\""))
                    {
                        Console.WriteLine("登陆PC的MAC地址不符合此用户的MAC地址限制策略");
                        return SCAN_LOGIN_OK; //???
                    }
                    return SCAN_LOGIN_FAILED;  //VM登录错误类型很多，找不到错误码的情况下，用户登录失败统一此值
                }
                else if (receive.Contains("var GJS_LOGINID =  \""))
                {
                    Console.WriteLine("登录成功");
                    return 0;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsMS(string IPAddr, string UserName, string Password)
        {
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string md5passwd = BitConverter.ToString(output).Replace("-", "");
            md5passwd = md5passwd.ToLower();

            string deviceurl = "http://" + IPAddr + ":8081/webui/login.php";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "username=" + UserName + "&passwd=" + md5passwd;

            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //根据返回关键字段判断登陆结果
                if (receive.Contains("'logout.php'"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("login.php"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsDM(string IPAddr, string UserName, string Password)
        {
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string md5passwd = BitConverter.ToString(output).Replace("-", "");
            md5passwd = md5passwd.ToLower();

            string deviceurl = "http://" + IPAddr + ":8080/webui/login.php";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "username=" + UserName + "&passwd=" + md5passwd;
            
            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //根据返回关键字段判断登陆结果
                if (receive.Contains("'logout.php'"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("login.php"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsBM(string IPAddr, string UserName, string Password)
        {
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string md5passwd = BitConverter.ToString(output).Replace("-", "");
            md5passwd = md5passwd.ToLower();

            string deviceurl = "http://" + IPAddr + ":8082/webui/login.php";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "username=" + UserName + "&passwd=" + md5passwd;

            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //根据返回关键字段判断登陆结果
                if (receive.Contains("'logout.php'"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("login.php"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsTS(string IPAddr, string UserName, string Password)
        {
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string md5passwd = BitConverter.ToString(output).Replace("-", "");
            md5passwd = md5passwd.ToLower();

            string deviceurl = "http://" + IPAddr + ":8085/login.php";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "username=" + UserName + "&passwd=" + md5passwd;

            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //根据返回关键字段判断登陆结果
                if (receive.Contains("'logout.php'"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("login.php"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsTMS(string IPAddr, string UserName, string Password)
        {
            byte[] result = Encoding.Default.GetBytes(Password);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] output = md5.ComputeHash(result);
            string md5passwd = BitConverter.ToString(output).Replace("-", "");
            md5passwd = md5passwd.ToLower();

            string deviceurl = "http://" + IPAddr + ":8083/webui/login.php";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "username=" + UserName + "&passwd=" + md5passwd;

            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //根据返回关键字段判断登陆结果
                if (receive.Contains("'logout.php'"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("login.php"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsIA(string IPAddr, string UserName, string Password)
        {
            return SCAN_SOCKET_TIME_OUT;
        }
        private Int32 TryLoginAsDA(string IPAddr, string UserName, string Password)
        {
            return SCAN_SOCKET_TIME_OUT;
        }
        private Int32 TryLoginAsIPSAN(string IPAddr, string UserName, string Password)
        {
            try
            {
                Process p = new Process();
                //p.StartInfo.FileName = "C:\\Program Files\\Java\\jre1.6.0_01\\bin\\java.exe";
                p.StartInfo.FileName = "java.exe";
                //p.StartInfo.EnvironmentVariables
                p.StartInfo.Arguments =  "-jar swguiclient.jar " + IPAddr + " " + UserName + " " + Password;
                p.StartInfo.UseShellExecute = false;
                //p.StartInfo.RedirectStandardInput = true;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

                p.Start();
                p.WaitForExit();
                string retInfo = p.StandardOutput.ReadToEnd();
                string errInfo = p.StandardError.ReadToEnd();
                p.Close();

                if (retInfo.Contains("Connect success"))
                {
                    return SCAN_LOGIN_OK;
                }
                else if (retInfo.Contains("Connect failed"))
                {
                    return SCAN_LOGIN_FAILED;
                }
                else if (retInfo=="")
                {
                    try 
                    {
                        Process p2 = new Process();
                        //p.StartInfo.FileName = "C:\\Program Files\\Java\\jre1.6.0_01\\bin\\java.exe";
                        p2.StartInfo.FileName = "java.exe";
                        //p.StartInfo.EnvironmentVariables
                        p2.StartInfo.Arguments = "-jar swguiclientold.jar " + IPAddr + " " + UserName + " " + Password;
                        p2.StartInfo.UseShellExecute = false;
                        //p.StartInfo.RedirectStandardInput = true;
                        p2.StartInfo.RedirectStandardOutput = true;
                        p2.StartInfo.RedirectStandardError = true;
                        p2.StartInfo.CreateNoWindow = true;
                        p2.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

                        p2.Start();
                        p2.WaitForExit();
                        string retInfo2 = p2.StandardOutput.ReadToEnd();
                        string errInfo2 = p2.StandardError.ReadToEnd();
                        p2.Close();
                        if (retInfo2.Contains("Connect success"))
                        {
                            return SCAN_LOGIN_OK;
                        }
                        else if (retInfo2.Contains("Connect failed"))
                        {
                            return SCAN_LOGIN_FAILED;
                        }
                        else if (retInfo2 == "")
                        {
                            return SCAN_SOCKET_TIME_OUT;
                        }
                    }
                    catch (Exception e)
                    {
                        //MessageBox.Show("e.Message");
                        return SCAN_UNKNOWN;
                    }
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show("e.Message");
                return SCAN_UNKNOWN;
            }
            return SCAN_UNKNOWN;
        }
        private Int32 TryLoginAsNVR(string IPAddr, string UserName, string Password)
        {
            System.Diagnostics.Debug.Print("Start HTTP " + DateTime.Now.ToString());

            DateTime d = DateTime.Now;
            Int32 retval = 0;
            try
            {
                byte[] result = Encoding.Default.GetBytes(Password);
                MD5 md5 = new MD5CryptoServiceProvider();
                byte[] output = md5.ComputeHash(result);
                string b = BitConverter.ToString(output).Replace("-", "");
                b = b.ToLower();

                HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create("http://" + IPAddr + "/cgi-bin/main-cgi"));
                myReq.Timeout = 5000;
                myReq.ReadWriteTimeout = 10000;  
                
                myReq.Method = "POST";
                myReq.ContentType = "application/x-www-form-urlencoded";
                string postData = "lLan=0&szUserName=" + UserName + "&szUserPasswd=" + b;
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] byte1 = encoding.GetBytes(postData);

                myReq.ContentLength = byte1.Length;

                Stream newStream = myReq.GetRequestStream();

                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();

                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();

                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                if (receive.Contains("code"))
                {
                    System.Diagnostics.Debug.Print(IPAddr + "登录失败" + UserName + ":" + Password);
                    if (receive.Contains("code=50801"))
                    {
                        System.Diagnostics.Debug.Print(IPAddr + "登录密码错误" + UserName + ":" + Password);
                        return SCAN_LOGIN_FAILED;
                    }
                    else if (receive.Contains("code=50802"))
                    {
                        System.Diagnostics.Debug.Print(IPAddr + "用户名不存在" + UserName + ":" + Password);

                        return SCAN_LOGIN_USERNOTEXIT;
                    }
                }
                else
                {
                    System.Diagnostics.Debug.Print(IPAddr + "登录成功" + UserName + ":" + Password);
                }
                return 0;
            }
            catch(System.Net.WebException ex)
            {
                retval = SCAN_PROTOCOL_REJECT;
            }

            catch(Exception ex)
            {
                retval = SCAN_UNKNOWN;
            }
            var s = DateTime.Now - d;
            System.Diagnostics.Debug.Print("Http cost time: "+s.ToString());
            //System.Threading.Thread.Sleep(5);
            return retval;
        }
        private Int32 TryLoginAsLOG(string IPAddr, string UserName, string Password)
        {
            string deviceurl = "http://" + IPAddr + "/LOGManage/loginVerify";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            //myReq.Accept = "application/json, text/javascript, */*";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "passwd=" + Password;
            
            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();

                //根据返回关键字段判断登陆结果
                if (receive.Contains("{\"tag\":true"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("{\"tag\":false"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsIPC(string IPAddr, string UserName, string Password)
        {
            return IpcCheck.CheckIPCPasswd(IPAddr, UserName, Password);
        }
        private Int32 TryLoginAsDB(string IPAddr, string UserName, string Password)
        {
            string deviceurl = "http://" + IPAddr + "/DBManage/loginVerify";
            HttpWebRequest myReq = (HttpWebRequest)(WebRequest.Create(deviceurl));
            myReq.Timeout = 5000; //单位毫秒
            myReq.ReadWriteTimeout = 10000;
            myReq.Method = "POST";
            //myReq.Accept = "application/json, text/javascript, */*";
            myReq.ContentType = "application/x-www-form-urlencoded";

            string postData = "passwd=" + Password;

            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] byte1 = encoding.GetBytes(postData);
            myReq.ContentLength = byte1.Length;
            try
            {
                Stream newStream = myReq.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                newStream.Close();
            }
            catch
            {
                Console.WriteLine("登录超时，网络不通或对端无响应");
                return SCAN_PROTOCOL_TIME_OUT;
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)myReq.GetResponse();
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = readStream.ReadToEnd();
                response.Close();
                readStream.Close();

                //根据返回关键字段判断登陆结果
                if (receive.Contains("{\"tag\":true"))
                {
                    Console.WriteLine("登录成功");
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("{\"tag\":false"))
                {
                    Console.WriteLine("登录密码错误");
                    return SCAN_LOGIN_FAILED;
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("无法连接");
                return SCAN_SOCKET_REJECT;
            }

            return SCAN_UNKNOWN;  //其他未知返回
        }
        private Int32 TryLoginAsDR(string IPAddr, string UserName, string Password)
        {
            string deviceurl = "http://" + IPAddr + "/dr/Vaild?passwd=" + Password + "&userName=" + UserName;
            try
            {
                System.Net.WebRequest wReq = System.Net.WebRequest.Create(deviceurl);
                wReq.Timeout = 5000;
                System.Net.WebResponse wResp = wReq.GetResponse();
                System.IO.Stream respStream = wResp.GetResponseStream();
                System.IO.StreamReader reader = new System.IO.StreamReader(respStream, Encoding.UTF8);
                Console.WriteLine("Response stream received.");
                //Console.WriteLine(readStream.ReadToEnd());
                String receive = reader.ReadToEnd();
                Console.WriteLine(receive);
                wResp.Close();
                reader.Close();
                if (receive.Contains("true"))
                {
                    return SCAN_LOGIN_OK;
                }
                else if (receive.Contains("false"))
                {
                    return SCAN_LOGIN_FAILED;
                }
                else
                {
                    return SCAN_UNKNOWN;
                }
            }
            catch(System.Exception ex)
            {
                return SCAN_PROTOCOL_TIME_OUT;
            }
        }
        public FormScan()
        {
            InitializeComponent();
            //LoadConfig();
            LoadFunctions();
        }

        private void LoadFunctions()
        {
            TestMethod f;

            f = new TestMethod();
            f.func = TryLoginAsVM;
            f.Desc = "."; //VM或行业NVR
            f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsIPC;
            f.Desc = ".."; //IPC
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsNVR;
            f.Desc = "..."; //分销NVR
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsECDC;
            f.Desc = "...."; //EC或DC
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginViaSSH;
            f.Desc = ".....";  //SSH
            //f.NeedMoreTest = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginViaTelnet;
            f.Desc = "......";  //Telnet
            //f.NeedMoreTest = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsDM;
            f.Desc = "......."; //DM
            f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsMS;
            f.Desc = "........"; //MS
            f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsBM;
            f.Desc = "........."; //BM
            f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsTMS;
            f.Desc = "..........";  //TMS
            f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsTS;
            f.Desc = "...........";  //TS
            //f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsLOG;
            f.Desc = "............";  //LOG服务器
            //f.IsVM = true;
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsDB;
            f.Desc = ".............";  //DB服务器
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsDR;
            f.Desc = "..............";  //DR服务器
            f.IsDevice = true;
            FunctionList.Add(f);

            f = new TestMethod();
            f.func = TryLoginAsIPSAN;
            f.Desc = "...............";   //IPSAN
            f.IsDevice = true;
            f.IsVM = true;
            FunctionList.Add(f);
        }
        string path_passwd = "./PasswordList.txt";
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "出厂密码")
            {
                path_passwd = "./PasswordList.txt";
            }
            else if (comboBox1.Text == "弱密码")
            {
                path_passwd = "./PasswordList2.txt";
            }
        }
        private void LoadConfig()
        {
            LoadCommonUserName();
            LoadCommonPassword(path_passwd);
        }
        
        private void LoadCommonPassword(string path)
        {
            StreamReader sr = new StreamReader(path, Encoding.Default);
            String line;
            while ((line = sr.ReadLine()) != null)
            {
                PasswordList.Add(line);
            }
        }
        private void LoadCommonUserName()
        {
            string path = "./UsernameList.txt";
            StreamReader sr = new StreamReader(path, Encoding.Default);
            String line;
            while ((line = sr.ReadLine()) != null)
            {
                UserNameList.Add(line);
            }
        }

        bool havejob = false;
        private void button1_Click(object sender, EventArgs e)
        {
            LoadConfig();
            try
            {
                if (IsValidIP(IPStart.Text) && (IsValidIP(IPEnd.Text)|| IPEnd.Text ==""))
                {
                    string[] ipstartlist = IPStart.Text.Split(new Char[] { '.' });
                    int ipstart2 = Convert.ToInt32(ipstartlist[2]);
                    int ipstart = Convert.ToInt32(ipstartlist[3]);
                    string stripend = IPEnd.Text;

                    if (stripend == "")
                    {
                        //添加IP地址
                        ListViewItem item = new ListViewItem();
                        item.SubItems[0].Text = ipstartlist[0] + "." + ipstartlist[1] + "." + ipstartlist[2] + "." + ipstartlist[3];
                        item.SubItems.Add("待扫描");
                        item.SubItems.Add("待扫描");
                        listViewDevcieUnderScan.Items.Add(item);
                    }
                    else
                    {
                        string[] ipendlist = IPEnd.Text.Split(new Char[] { '.' });
                        int ipend2 = Convert.ToInt32(ipendlist[2]);
                        int ipend = Convert.ToInt32(ipendlist[3]);
                        if (ipend2 > ipstart2)
                        {
                            for (int i = ipstart2; i <= ipend2; i++)
                            {
                                int k = i;
                                if (k == ipend2)
                                {
                                    for (int j = 0; j <= ipend; j++)
                                    {
                                        //添加IP地址
                                        ListViewItem item = new ListViewItem();
                                        item.SubItems[0].Text = ipstartlist[0] + "." + ipstartlist[1] + "." + k.ToString() + "." + j.ToString();
                                        item.SubItems.Add("待扫描");
                                        item.SubItems.Add("待扫描");
                                        listViewDevcieUnderScan.Items.Add(item);
                                        if (listViewDevcieUnderScan.Items.Count == 1000)
                                        {
                                            MessageBox.Show("您添加的设备数量已超过1000!");
                                            break;
                                        }
                                    }
                                   
                                }
                                else
                                {
                                    for (int j = ipstart; j <= 255; j++)
                                    {
                                        //添加IP地址
                                        ListViewItem item = new ListViewItem();
                                        item.SubItems[0].Text = ipstartlist[0] + "." + ipstartlist[1] + "." + k.ToString() + "." + j.ToString();
                                        item.SubItems.Add("待扫描");
                                        item.SubItems.Add("待扫描");
                                        listViewDevcieUnderScan.Items.Add(item);
                                        if (listViewDevcieUnderScan.Items.Count == 1000)
                                        {
                                            MessageBox.Show("您添加的设备数量已超过1000!");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            for (int i = ipstart; i <= ipend; i++)
                            {
                                //添加IP地址
                                ListViewItem item = new ListViewItem();
                                item.SubItems[0].Text = ipstartlist[0] + "." + ipstartlist[1] + "." + ipstartlist[2] + "." + i.ToString();
                                item.SubItems.Add("待扫描");
                                item.SubItems.Add("待扫描");
                                listViewDevcieUnderScan.Items.Add(item);
                            }
                        }
                    }
                    havejob = true;
                }
                else
                {
                    MessageBox.Show("请输入正确的IP地址!");
                }
            }
            catch
            {
                MessageBox.Show("请输入起始/结束IP地址!");
            }
        }
        
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        class ThreadArg
        {
            public ListViewItem item;
            public string Text;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string select_path = ConfigurationManager.AppSettings["java_path"];
            SetEnvironmentVariable("PATH",select_path);
            StartManyThreadToDoHardJob(10);
            listViewDevcieUnderScan.BackgroundImage = null;
        }

        private void StartManyThreadToDoHardJob(int C)
        {
            if (!havejob)
            {
                return;
            }
            for (int i = 0; i < C; i++)
            {
                var backgroundWorker1 = new BackgroundWorker();
                backgroundWorker1.DoWork += this.backgroundWorker1_DoWork;
                backgroundWorker1.RunWorkerCompleted += this.backgroundWorker1_RunWorkerCompleted;
                //System.Threading.Thread.Sleep(1000);
                ThreadArg arg = new ThreadArg();
                arg.Text = "xxx";
                backgroundWorker1.RunWorkerAsync(arg);
            }
        }

        private delegate void UpdateItemStatusInvokeCallback(ListViewItem item, string devType, string passwdScan, Color cr);
        private void UpdateItemStatus(ListViewItem item, string devType, string passwdScan, Color cr)
        {            
            if (listViewDevcieUnderScan.InvokeRequired)
            {
                var InvokeCallbackmsgCallback = new UpdateItemStatusInvokeCallback(UpdateItemStatus);
                listViewDevcieUnderScan.Invoke(InvokeCallbackmsgCallback, new object[] { item, devType, passwdScan, cr });
            }
            else
            {
                item.SubItems[1].Text = devType;
                item.SubItems[2].Text = passwdScan;
                item.BackColor = cr;
            }
        }

        private void AddItemStatus(ListViewItem item, string devType, string passwdScan, Color cr)
        {
            // ListViewItem WorkingItem = null;
            if (listViewDevcieUnderScan.InvokeRequired)
            {
                var InvokeCallbackmsgCallback = new UpdateItemStatusInvokeCallback(AddItemStatus);
                listViewDevcieUnderScan.Invoke(InvokeCallbackmsgCallback, new object[] { item, devType, passwdScan, cr });
            }
            else
            {
                lock(listViewDevcieUnderScan)
                { 
                    ListView lv = item.ListView;
                    ListViewItem newItem = lv.Items.Insert(item.Index + 1, "");
                    newItem.BackColor = Color.Yellow;
                    newItem.Tag = "HaveDone";
                    Font defaultfont = newItem.Font;
                    newItem.SubItems.Add(devType, Color.Black, Color.Yellow, defaultfont);
                    newItem.SubItems.Add(passwdScan, Color.Black, Color.Yellow, defaultfont);
                }
                //newItem.SubItems[1].Text = devType;
                //newItem.SubItems[2].Text = passwdScan;
            }
        }

        private delegate void backgroundWorker1_DoWorkInvokeCallback(object sender, DoWorkEventArgs e); 
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            ListViewItem WorkingItem = null;

            //MessageBox.Show("backgroundWorker1_DoWork");

            if (listViewDevcieUnderScan.InvokeRequired)
            {

                //MessageBox.Show("tttttttt" + this.g_test.ToString());
                System.Diagnostics.Debug.Print("Start thread..");
                var InvokeCallbackmsgCallback = new backgroundWorker1_DoWorkInvokeCallback(backgroundWorker1_DoWork);
                listViewDevcieUnderScan.Invoke(InvokeCallbackmsgCallback, new object[] { sender, e });

                if (WorkingItem == null)
                {
                    //return;
                }                // 开始扫描
                /*MessageBox.Show("tttttttt" + this.g_test.ToString());
                if(!havejob)
                {
                    return;
                }*/
                bool FindVM = false;
                bool FindDevice = false;
                bool FindIP = false;
                bool FindUserNotExist = false;
                bool FindUnResponseDevice = false;
                bool FindCurrentUserPasswordWeak = false;
                bool DeviceIsWeek = false;

                foreach (TestMethod f in FunctionList)
                {
                    FindUnResponseDevice = false;
                    FindCurrentUserPasswordWeak = false;
                    foreach (string username in UserNameList)
                    {
                        FindUserNotExist = false;
                        foreach (string password in PasswordList)
                        {
                            if (FindCurrentUserPasswordWeak)
                            {
                                // 既然密码找到了，就OK了
                                break;
                            }
                            if (FindUnResponseDevice)
                            {
                                // 既然设备没用响应，就不用尝试了
                                break;
                            }

                            if (FindUserNotExist)
                            {
                                // 既然已经明确返回用户不存在了，就不用尝试密码了，下一个用户名
                                break;
                            }

                            if (FindVM)
                            {
                                // 如果是VM系列产品，就不要扫描其它类型设备了.VM系列还是要扫描
                                if ((f.IsDevice == true) && (f.IsVM != true))
                                {
                                    break;
                                }
                            }
                            else if (FindDevice)
                            {
                                if ((f.IsDevice == true) && (f.IsVM == true))
                                {
                                    break;
                                }
                            }

                            WorkingItem = (e.Argument as ThreadArg).item;

                            if (WorkingItem == null)
                            {
                                return;
                            }

                            UpdateItemStatus(WorkingItem, "扫描中" + f.Desc, "扫描中...", WorkingItem.BackColor);
                            string ip = WorkingItem.Text;
                            int ret = f.func(ip, username, password);

                            switch (ret)
                            {
                                case SCAN_LOGIN_OK:
                                    AddItemStatus(WorkingItem, f.Desc, "弱密码(" + username + "/" + password + ")", WorkingItem.BackColor);
                                    //WorkingItem.BackColor = Color.Yellow;
                                    //goto StopCheck;
                                    DeviceIsWeek = true;
                                    FindCurrentUserPasswordWeak = true;
                                    if (f.IsDevice == true)
                                    {
                                        FindDevice = true;
                                    }
                                    if (f.IsVM == true)
                                    {
                                        FindVM = true;
                                    }
                                    FindIP = true;
                                    break;
                                case SCAN_LOGIN_USERNOTEXIT:
                                    //goto NextUser;                                    
                                    if (f.IsDevice == true)
                                    {
                                        FindDevice = true;
                                    }
                                    if (f.IsVM == true)
                                    {
                                        FindVM = true;
                                    }
                                    FindIP = true;
                                    FindUserNotExist = true;
                                    break;

                                case SCAN_NOJAVA:
                                case SCAN_SOCKET_TIME_OUT:
                                case SCAN_PROTOCOL_TIME_OUT:
                                case SCAN_SOCKET_REJECT:
                                case SCAN_PROTOCOL_REJECT:
                                    //goto NextFunction;
                                    FindUnResponseDevice = true;
                                    break;

                                case SCAN_UNKNOWN:
                                    break;

                                case SCAN_LOGIN_FAILED:
                                    FindIP = true;
                                    break;
                                default:
                                    break;
                            }
                        // NextUser: ;
                        }
                        //NextUser: ;
                    }
                    //NextFunction: ;
                }

                if (FindIP == false)
                {
                    UpdateItemStatus(WorkingItem, "完成", "无响应或不支持的设备", WorkingItem.BackColor);
                }
                else
                {
                    if (DeviceIsWeek)
                    {
                        UpdateItemStatus(WorkingItem, "完成", "存在弱密码", Color.Yellow);
                    }
                    else
                    {
                        //FindWeekPassword
                        UpdateItemStatus(WorkingItem, "完成", "不存在弱密码", WorkingItem.BackColor);
                    }
                }
                //StopCheck: ;

                /*
                 * ListViewItem item = new ListViewItem();
                
                foreach (TestMethod f in FunctionList2)
                {
                    foreach (string username in UserNameList)
                    {
                        foreach (string password in PasswordList)
                        {
                            WorkingItem = (e.Argument as ThreadArg).item;
                            string ip = WorkingItem.Text;
                            //ListViewItem item = new ListViewItem();
                            //item.SubItems[0].Text = ip;
                            //item.SubItems.Add("待扫描");
                            //item.SubItems.Add("待扫描");
                            //listViewDevcieUnderScan.Items.Add(item);

                            int ret = f.func(ip, username, password);

                            switch (ret)
                            {
                                WorkingItem = item;
                                item.Tag = sender;

                                ThreadArg arg = e.Argument as ThreadArg;
                                arg.Text = "WorkingItem";
                                arg.item = WorkingItem;
                                findany = true;
                                System.Diagnostics.Debug.Print("Start job.");
                                break;
                            }
                        }
                    NextUser: ;
                    }
                    NextFunction: ;
                    
                }
                UpdateItemStatus(item, "完成", "不存在弱密码");
                StopCheck2: ;*/
            }
            else
            {
                DateTime a = DateTime.Now;
                lock (listViewDevcieUnderScan)
                {
                    bool findany = false;
                    foreach (ListViewItem item in listViewDevcieUnderScan.Items)
                    {
                        if (item.Tag == null)
                        {
                            WorkingItem = item;
                            item.Tag = sender;

                            ThreadArg arg = e.Argument as ThreadArg;
                            arg.Text = "WorkingItem";
                            arg.item = WorkingItem;
                            findany = true;
                            System.Diagnostics.Debug.Print("Start job.");
                            break;
                        }
                    }

                    if(!findany)
                    {
                        System.Diagnostics.Debug.Print("No more jobs");
                        havejob = false;                        
                    }
                }

                var b = DateTime.Now - a;
                System.Diagnostics.Debug.Print("Lock cost: " + b.Ticks.ToString());
                
            }
            
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
           StartManyThreadToDoHardJob(10);
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadConfig();
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = System.Windows.Forms.Application.StartupPath;
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(ofd.FileName))
                {
                    string s = sr.ReadToEnd();
                    string[] lines = s.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var data in lines)
                    {

                        if (IsValidIP(data))
                        {
                            try
                            {
                                ListViewItem item = new ListViewItem();
                                item.SubItems[0].Text = data;
                                item.SubItems.Add("待扫描");
                                item.SubItems.Add("待扫描");
                                listViewDevcieUnderScan.Items.Add(item);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("格式错误！");
                            }
                            
                        }
                        else 
                        {
                            MessageBox.Show("您导入的文本中存在格式不正确的IP地址！");
                            break;
                        }
                    }
                }
            }
            havejob = true;
        }
        public bool IsValidIP(string ip)
        {
            string pattrn = @"((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))";
            if (System.Text.RegularExpressions.Regex.IsMatch(ip, pattrn))
            {
                string[] ips = ip.Split('.');
                if (ips.Length == 4 || ips.Length == 6)
                {
                    System.Text.RegularExpressions.Regex rex = new System.Text.RegularExpressions.Regex(@"^\d+$");

                    for (int i = 0; i < ips.Length;i++ )
                    {
                        if (!rex.IsMatch(ips[i]))
                        {
                            return false;
                        }
                    }

                    if (System.Int32.Parse(ips[0]) < 256 && System.Int32.Parse(ips[1]) < 256 & System.Int32.Parse(ips[2]) < 256 & System.Int32.Parse(ips[3]) < 256)

                        return true;
                    else
                        return false;

                }
                else
                    return false;

            }

            else
                return false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //if (MessageBox.Show("是否要退出扫描？", "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.Cancel)
            //{
                this.Close();  
            //}     
        }

        private void FormScan_Load_1(object sender, EventArgs e)
        {
            Version currentVersion = Environment.OSVersion.Version;
            Version compareToVersion = new Version("6.2");
            if (currentVersion.CompareTo(compareToVersion) >= 0)
            {
                Text = "宇视弱密码扫描工具（V1.2 win8版）";
            }
            else
            {
                Text = "宇视弱密码扫描工具（V1.2 win7版）";
            }
        }

        [Flags]
        public enum SendMessageTimeoutFlags : uint
        {
            SMTO_NORMAL = 0x0000,
            SMTO_BLOCK = 0x0001,
            SMTO_ABORTIFHUNG = 0x0002,
            SMTO_NOTIMEOUTIFNOTHUNG = 0x0008
        }
        const int WM_SETTINGCHANGE = 0x001A;
        const int HWND_BROADCAST = 0xffff;
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool SetEnvironmentVariable(string lpName, string lpValue);
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]

        public static extern IntPtr SendMessageTimeout(
            IntPtr windowHandle,
            uint Msg,
            IntPtr wParam,
            string lParam,
            SendMessageTimeoutFlags flags,
            uint timeout,
            out IntPtr result);

        private void button5_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ofd = new FolderBrowserDialog();
            
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                if (!System.IO.File.Exists(ofd.SelectedPath + "\\java.exe"))
                    MessageBox.Show("对不起，您选择的路径有误，请重新选择！");
                try
                {
                    XmlDocument xDoc = new XmlDocument();

                    //获取App.config文件绝对路径
                    string str = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
                    str = str + "DevScan.exe.config";
                    xDoc.Load(str);

                    XmlNode xNode;

                    XmlElement xElem1;

                    xNode = xDoc.SelectSingleNode("//appSettings");

                    xElem1 = (XmlElement)xNode.SelectSingleNode("//add[@key='" + "java_path" + "']");
                    xElem1.SetAttribute("value", ofd.SelectedPath);

                    xDoc.Save(str);
                }
                catch (Exception ex)
                {
                    string error = ex.Message;

                }

                //Configuration cfa = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                //cfa.AppSettings.Settings["java_path"].Value = ofd.SelectedPath;
                //cfa.Save();
                //ConfigurationManager.RefreshSection("appSettings");// 刷新命名节，在下次检索它时将从磁盘重新读取它。记住应用程序要刷新节点
                /*SetEnviromentVari.SetPathAfter(path);
                IntPtr result1;
                //修改后发送一个消息给系统 
                //调用
                SendMessageTimeout(
                    new IntPtr(HWND_BROADCAST),
                    WM_SETTINGCHANGE,
                    IntPtr.Zero,
                    "Environment",
                    SendMessageTimeoutFlags.SMTO_ABORTIFHUNG,
                    200,
                    out result1);*/
            }
        }
    }
}
